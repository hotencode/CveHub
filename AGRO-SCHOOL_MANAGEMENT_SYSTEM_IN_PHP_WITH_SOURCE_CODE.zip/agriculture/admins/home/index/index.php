<?php 
include("../../header.php");
//include("modals.php");

?>

  <!-- =============================================== -->

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->  
      <section class="content-header">
      
      <div class="callout callout-info">
        <h4>Welcome
        


             <i>   <?php echo $_SESSION['firstname']." ". $_SESSION['lastname'] ?> ! </h4>
      </div>

 




    <!--    <small>Blank example to the fixed layout</small> -->


    <!-- Main content -->

            

            


 
      <!-- /.row -->
  </section>
    <!-- /.content -->
  
        </div>






<?php include("../../footer.php"); ?>